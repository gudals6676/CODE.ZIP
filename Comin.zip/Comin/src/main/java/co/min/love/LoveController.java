package co.min.love;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.google.gson.Gson;

import co.min.domain.UserVO;
import co.min.mapper.cominMapper;
import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class LoveController {
	

	//처리순서 컨트롤러 -> 서비스 -> DAO ->서비스 -> 컨트롤러
	private static final org.slf4j.Logger logger =  LoggerFactory.getLogger(LoveController.class);
	
	@Inject
	private cominMapper cominMapper;
	
	@RequestMapping("/")
	public String home() {
		return "home";
	}
	@RequestMapping("/home.do")
	public String main() {
		return "home";
	}
	@RequestMapping("/gologin.do")
	public String login() {
		return "login";
	}
	@RequestMapping("/join.do")
	public String join() {
		return "join";
	}
	// 회원가입
	@RequestMapping("/userInsert.do")
	public String MinInsert(UserVO vo) {
		cominMapper.userInsert(vo);
		System.out.println("들어와?");
		return "home";
	}
	//로그인 처리
		@RequestMapping(value = "/login", method = RequestMethod.POST)
		public ModelAndView memberLogin( UserVO vo, HttpServletRequest req, RedirectAttributes rttr) throws Exception{
			logger.info("Login");
			
			HttpSession session = req.getSession();
			UserVO user = cominMapper.userLogin(vo);
			
			String msg = "msg";
			
			ModelAndView mav = new ModelAndView(); // 리다이렉트 안해도 jsp 찾아감
			if(user == null) {
				//로그인 실패처리 
				session.setAttribute("member", null);
				session.setAttribute("msg", msg);
				mav.setViewName("join");
				mav.addObject("msg","로그인 실패다임마");
			}else {
				//로그인 성공처리
				session.setAttribute("msg", null);
				session.setAttribute("member", user);
				session.setAttribute("user", user);
				System.out.println(user.getU_id()+"얌마야망마아마음내아매낭매나");
				mav.setViewName("home");
				mav.addObject("msg","로그인 성공쓰");
			}
			return mav;
			//return null;
		}
		// 로그아웃 기능
	      @RequestMapping("/logout.do")
	      public String logout(HttpServletRequest request) { // 로그아웃 기능
	         System.out.println("로그아웃하러들어옴");
	         HttpSession session = request.getSession();
	         session.invalidate();
	         return "home"; //redirect 쓰는 이유는 페이지 이동없이 바로 ㄱㄱ
	      }
}
