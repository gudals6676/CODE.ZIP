package co.min.mapper;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;

import co.min.domain.UserVO;

@Mapper
public interface cominMapper {

	public String home();
	
	public String login();
	
	public String join();
	
	@Insert("insert into tbl_user(u_id,u_pw,name,Ic_num,num) values(#{u_id},#{u_pw},#{name},#{Ic_num},#{num})")
	public void userInsert(UserVO vo);

	public UserVO userLogin(UserVO vo);
	
	public String logout(); // 로그아웃 기능
}
