package co.min.domain;

import lombok.Data;

@Data
public class UserVO {
	String u_id;
	public String getU_id() {
		return u_id;
	}
	public void setU_id(String u_id) {
		this.u_id = u_id;
	}
	public String getU_pw() {
		return u_pw;
	}
	public void setU_pw(String u_pw) {
		this.u_pw = u_pw;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getIc_num() {
		return Ic_num;
	}
	public void setIc_num(String ic_num) {
		Ic_num = ic_num;
	}
	public String getNum() {
		return num;
	}
	public void setNum(String num) {
		this.num = num;
	}
	String u_pw;
	String name;
	String Ic_num; //주민번호
	String num;    //전화번호
	
}
