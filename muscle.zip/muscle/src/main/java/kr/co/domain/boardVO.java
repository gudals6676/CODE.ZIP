package kr.co.domain;

import lombok.Data;

@Data
public class boardVO {
   private int idx_b;
   private String title;
   private String content;
   private String id;
   
}