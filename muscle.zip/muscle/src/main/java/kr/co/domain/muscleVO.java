package kr.co.domain;

import lombok.Data;

@Data
public class muscleVO {
   private int idx_d;
   private String word;
   private String video;
}