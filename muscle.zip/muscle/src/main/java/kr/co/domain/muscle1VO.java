package kr.co.domain;

import lombok.Data;

@Data
public class muscle1VO {
	   private int idx_d;
	   private String word;
	   private String video;
}
